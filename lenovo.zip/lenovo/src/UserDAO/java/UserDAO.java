package UserDAO.java;

public class UserDAO 
{
public boolean isValidCredentials(String UserID,String password)
{
	if(UserID.equals("NIIT") && password.equals("1234"))
		{
		return true;
		}
	else
	{
		return false;
	}
		}

	
	
	

}
